# MusePack Builder

Use this skill when the user asks you to turn one of their spaces into
a MusePack — "make a pack from this space," "package this so other
people can install it," "create a MusePack."

## The role (why this skill exists)

**You are the author. The creator decides. The pack is data.**

The MusePack Installer skill, on the recipient's machine, is your
counterpart: it treats a pack as declarative data and builds from it.
Your job is the reverse — go from a living space to that data,
faithfully. Two disciplines govern everything below:

- **Propose, never decide silently.** What is fixed design vs. asked of
  the recipient, and what personal data may ship, are the creator's
  calls. You surface the choices; the creator makes them.
- **Nothing personal ships by accident.** The pack leaves the creator's
  machine and lands on strangers' machines. Every piece of the
  creator's own data in it must be there because the creator explicitly
  approved that item.

This builder is the first of three quality gates for a pack (creation
here; the listing site's checks at submission; the installer's Quality
& Safety gate at install). Produce packs that can pass the later gates
without the creator in the loop.

## How to work (read this first)

- **Show progress.** Before and after each major step, say one short
  line about what you're doing and what happened ("Inspecting the
  space…", "Found 3 things that need your decision"). Never work
  silently for a long stretch and then dump everything at once.
- **One decision at a time.** Anything that needs the creator's
  judgment — the fidelity choice, approval of each proposed
  question, each privacy item, each declaration topic — is asked on
  its own: ask it, wait for the answer, then move on. Never hand
  the creator a list of questions to answer in bulk.
- **Batch facts, never decisions.** Inspection findings and the
  fixed-design list are information and may be presented together.
  A request for decisions may not be.
- **Keep reports short.** The final report is the headline outcome
  plus anything that needs attention. The full detail lives in the
  creation record — point to it, don't paste it into chat.

## Procedure

1. **Name the source space.** The creator names the space to package.
   If it's ambiguous, list their spaces and ask. A pack ships **one
   space** — if the creator wants two spaces shared, that's two packs.
   Note anything attached to the space's workflow: companion skills
   the creator uses with it, side chats about it, schedules that act
   on it. You'll settle each one's place in step 6.
2. **Inspect the live space — never author from memory.** Enumerate
   the space's actions and their schemas from the live space itself.
   Generate the **surface inventory** — every tab/screen, in order,
   with its name and what it contains — from the live space, not from
   the creator's description or your recollection of similar spaces.
   Read the space's current data to learn its shape: what records,
   settings, and generated content exist. (A pack once shipped with a
   surface inventory written from memory; two installs then built
   different tab bars. The inventory is a contract — get it from the
   source.) If you cannot inspect the live space, stop and say so;
   do not reconstruct it from conversation.
3. **Ask the fidelity question.** Ask the creator how exactly a
   recipient's rebuild must match the original:
   - **Standard:** the pinned surface inventory and spec carry the
     design; installs will be faithful in structure and behavior.
   - **Reference screenshots:** additionally capture the key surfaces
     as images, shipped in the pack's `assets/` folder and named in
     the verify list, so an installing Muse can compare its build
     against them. Capture **empty states** wherever possible. Where
     you cannot capture a surface yourself, ask the creator to supply
     the screenshot. Screenshots pass through the privacy gate in
     step 5 like everything else — a screenshot showing the creator's
     records is personal data.
   Be honest about what screenshots buy: a close visual match, checked
   at verify time. A rebuild is still a rebuild, not a photocopy.
4. **Propose the split — pattern vs. instance.** From the inspection,
   draft three lists:
   - **Fixed:** design and behavior that ship exactly as they are
     (layout, scales, methods, field sets). Present this list as
     information — it's what you found, not a decision.
   - **Questions:** settings a recipient may choose. For each, draft
     the key, prompt, options, and default. **A default may only be a
     design value** (a count, a mode, a color) — never the creator's
     personal data. A question whose answer is personal to each
     recipient (their location, name, accounts, content) is drafted
     `required: true` with **no default**. Then walk the creator
     through the proposed questions **one at a time** for approval:
     keep it as a question, make it fixed, reword it, or drop it.
   - **Data:** what records and content currently live in the space.
     Present the kinds as information here; the disposition of each
     item is decided in step 5.
   Nothing is asked of recipients by default: a setting becomes a
   question only because the creator chose to ask it.
5. **Run the privacy gate — surface and ask (blocking).** Scan
   everything destined for the pack — seed data, examples, question
   defaults, verify text, spec text, companion skill text, rules, and
   screenshots — for candidate personal data: names, locations,
   addresses, accounts, the creator's own records and answers,
   generated content about the creator. Present **each candidate item
   to the creator individually** and ask whether it may ship:
   include as-is, generalize it (keep the pattern, replace the
   personal value), or exclude it. **The default is exclude.** Nothing
   personal ships silently in either direction — not by inclusion,
   and not by scrubbing something the creator wanted kept without
   asking. Do not proceed with any item undispositioned. Seed data
   that ships is generic content only; the creator's records ship
   only as empty structures unless the creator explicitly approved
   specific items above.
6. **Interview the declarations.** Settle each of these with the
   creator, **one topic at a time** — finish each before starting
   the next:
   - **Companion skills.** Which of the creator's skills belong to
     this pack? Extract each one and generalize it the same way —
     its text goes through steps 4–5 too.
   - **Side chats.** Ask which starter side chats the pack includes
     and what each is for. Write each as an entry in a single root
     `side-chats.yaml`: `id`, `title`, `purpose`, and a `focus` brief
     written fresh for recipients — the brief is sent as the chat's
     founding message, so it is never a hidden prompt and never the
     creator's own chat transcript. Declare `space:` (this pack's
     space) and `skills:` (this pack's companion skills) associations
     where the chat works with them; associations must resolve inside
     this pack.
   - **Schedules.** Any recurring jobs the pack can set up — each one
     its own entry (cadence, prompt, delivery), always opt-in for the
     recipient, never created silently at install.
   - **Connectors and capabilities.** What the space actually uses:
     account connectors (things a recipient connects with their own
     login) go in `connectors.yaml`; built-in Muse capabilities
     (no account, nothing to connect) go in `capabilities.yaml`. Each
     entry carries `requirement` (required|optional), `used_by`
     naming **real component ids** of this pack (the space's id,
     skill names, side-chat ids, schedule ids — never generic words),
     `purpose`, and its fallback (`if_declined` for connectors,
     `if_unavailable` for capabilities).
   - **Rules.** Standing behavior for the pack's own components goes
     in `rules.yaml`. Rules are **pack-scoped only**: a rule that
     would govern the recipient's Muse beyond this pack's space,
     chats, skills, and schedules does not ship.
7. **Generate the pack folder.** Write `<pack-name>/` at the
   current MusePack format standard:
   - `musepack.yaml` — the manifest: name, `version: 0.1.0`,
     `format: musepack`, `installer_skill: musepack-installer`,
     title, description, author, license, `files:` (relative links to
     everything shipped), `requires:`, `contents:`, `questions:`
     (from step 4, with `{{placeholder}}` answers substituted by the
     installer), `install_order:`, `verify:` (step 8), and
     `test_install:` (slug/name suffixes so a test install never
     overwrites the original). **Data only** — no imperative
     instruction blocks anywhere in the pack.
   - `space/SPACE.yaml` (header), `space/SPACE.md` (the full spec,
     carrying the pinned surface inventory from step 2),
     `space/actions.json` (every action + schema from the live
     space), `space/seed.json` (generic content only, per step 5).
   - `skills/<skill-name>/` for each companion skill (SKILL.md +
     skill.yaml).
   - **All five declaration files, always present** — `rules.yaml`,
     `schedules.yaml`, `side-chats.yaml`, `connectors.yaml`,
     `capabilities.yaml` — an empty list where the pack needs none.
     "None" is said explicitly, never by omission.
   - `CHANGELOG.md` with the 0.1.0 entry, in human words.
   - `assets/` when screenshots ship, plus `assets/README.md` saying
     what each image is and why it ships.
   Keep a working copy of the pack at
   `~/workspace/musepacks/<pack-name>/` as the creation record,
   including the step 4–6 decisions.
8. **Write the verify list.** Checks the installer can actually run
   against a finished install, mirroring what matters: the surface
   check (built tab bar/screens exactly match the pinned inventory,
   in order — and the reference screenshots, when shipped), the
   empty-start check (the space starts with no creator data), a
   functional check per major action, and the existence of each
   starter side chat opened with its focus brief. Every
   `{{placeholder}}` used anywhere in the pack must be covered by a
   question from step 4.
9. **Compute integrity hashes — last.** After every other file is
   final, compute the SHA-256 of every shipped file (the manifest
   itself excluded — it is what a future signature will cover) and
   write them into the manifest's `integrity:` section. Any later
   edit to any file means recompute; a pack whose hashes don't match
   its files is a pack the installer will refuse.
10. **Run the creation gate — validate before handoff.** Check the
    finished folder the way the installer's gate will: every YAML/JSON
    parses; every `files:` link resolves; **leak re-scan** — search
    the final files for each personal item excluded or generalized in
    step 5 and confirm it does not appear; every `used_by` id and
    every side-chat association resolves to a component of this pack;
    all five declaration files present; the verify list present and
    including the surface check; CHANGELOG present; hashes recomputed
    and matching. Any failure: fix it, recompute hashes if files
    changed, and re-run. Never hand over a pack that fails its own
    gate. When the creator is ready to publish, zip the folder and
    verify the zip's contents match the folder exactly.
11. **Report and recommend a test.** Keep the report to the headline:
    the pack's name and version, what is fixed vs. asked in one line,
    how many privacy items were found and how they were decided in
    summary (the per-item record lives in the creation record, not
    in chat). Then give the exact **guarded
    install prompt** for the pack (verify the `musepack-installer`
    skill first — if missing, stop and install it — otherwise install
    this pack, naming the pack's folder URL); and a **catalog entry**
    for the pack (name, title, version, one-line description,
    category, folder URL) in YAML, ready to add to the MusePack
    catalog when the creator publishes. Recommend a test install
    before publishing: in a separate chat, install the pack (it will
    build under the test slug) and compare the result against the
    original space, surface by surface.

## Keeping this builder up to date

This builder updates itself through an **opt-in daily check** — it
never updates silently, and it never applies an update without asking.
The mechanism is identical to the MusePack Installer's:

**Offer the check once, at first use.** Offer to create a daily
schedule named "MusePack Builder update check" and explain exactly
what it does, in one or two sentences. If the user declines, don't
create it and don't keep asking.

**What the daily check does.** Fetch the `update_check.version_url`
from this skill's `skill.yaml` — a small JSON file hosted next to the
builder zip, carrying the latest published version. Compare it with
the installed version in `skill.yaml`:

- **Same or older:** do nothing. No message, no noise.
- **Newer:** tell the user the current and new versions and the
  published notes from the version file, and ask whether to update.
  Only on a yes, run the update as one transaction:
  1. Download `update_check.zip_url` and confirm the zip's
     `skill.yaml` really carries the newer version — before touching
     the current install, so a bad download changes nothing.
  2. Move the current skill folder aside as a *temporary* backup
     (`musepack-builder-backup-<old version>` next to it).
  3. Install the new folder in its place, then verify the installed
     copy: its `skill.yaml` carries the new version and its files are
     complete.
  4. **On verified success: delete the backup**, then confirm the new
     version to the user. No backup folders are left behind.
  5. **On any failure after the backup was made:** delete the partial
     new install, restore the backup as the live skill folder, clean
     up anything else the update left behind, and tell the user the
     update failed and they are still on the old version. Never leave
     both versions in place, and never leave a half-swapped install.
- **Fetch fails** (offline, site down): stay quiet and try again
  tomorrow. Never report a failed check as an available update.

**Scope.** This mechanism updates the builder itself only. The packs
it has created are not auto-checked or auto-updated.
